<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];

$stmt_turmas = $conexao->prepare("SELECT id_turma, nome FROM Turma WHERE id_professor = ?");
$stmt_turmas->bind_param("i", $id_professor);
$stmt_turmas->execute();
$result_turmas = $stmt_turmas->get_result();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'] ?? null;
    $descricao = $_POST['descricao'] ?? null;
    $id_turma = $_POST['id_turma'] ?? null;

    if (!empty($titulo) && !empty($id_turma)) {
        $stmt = $conexao->prepare("INSERT INTO Atividade (titulo, descricao, id_professor, id_turma) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssii", $titulo, $descricao, $id_professor, $id_turma);

        if ($stmt->execute()) {
            echo "Atividade cadastrada com sucesso!";
        } else {
            echo "Erro ao cadastrar a atividade.";
        }
        $stmt->close();
    } else {
        echo "Por favor, preencha todos os campos obrigatórios.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Atividade</title>
</head>
<body>
    <h1>Cadastrar Nova Atividade</h1>
    <form action="atividades.php" method="post">
        <label for="titulo">Título da Atividade:</label>
        <input type="text" id="titulo" name="titulo" required>

        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao"></textarea>

        <label for="id_turma">Turma:</label>
        <select id="id_turma" name="id_turma" required>
            <option value="">Selecione uma turma</option>
            <?php while ($turma = $result_turmas->fetch_assoc()): ?>
                <option value="<?= $turma['id_turma'] ?>"><?= $turma['nome'] ?></option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Cadastrar</button>
    </form>
    <a href="professor.php">Voltar</a>
</body>
</html>
