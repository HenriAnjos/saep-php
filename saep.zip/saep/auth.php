<?php
session_start();

if (!isset($_SESSION['id_professor']) || !isset($_SESSION['nome_professor'])) {
    header('Location: login.php');
    exit;
}
?>
