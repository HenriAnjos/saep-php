<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];
$id_turma = $_GET['id_turma'] ?? null;

if (!$id_turma) {
    echo "Turma não especificada.";
    exit;
}

$stmt_turma = $conexao->prepare("SELECT id_turma FROM Turma WHERE id_turma = ? AND id_professor = ?");
$stmt_turma->bind_param("ii", $id_turma, $id_professor);
$stmt_turma->execute();
$result_turma = $stmt_turma->get_result();

if ($result_turma->num_rows === 0) {
    echo "Erro: A turma não pertence a você.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Nova Atividade</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 160px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #2196F3;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        textarea {
            height: 100px;
            resize: vertical;
        }
        button {
            background-color: #2196F3;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #1976D2;
        }
        .voltar-container {
            text-align: center;
            margin-top: 20px;
        }
        .voltar {
            display: inline-block;
            background-color: red;
            color: white;
            padding: 10px 15px;
            border: 2px solid #f44336;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
        }
        .voltar:hover {
            background-color: #f44336;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>Cadastrar Nova Atividade</h1>
    <form action="processar_cadastro_atividade.php" method="post">
        <input type="hidden" name="id_turma" value="<?= $id_turma ?>">
        <label for="titulo">Título da Atividade:</label>
        <input type="text" id="titulo" name="titulo" required>

        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao"></textarea>

        <button type="submit">Cadastrar</button>
    </form>
    <div class="voltar-container">
    <a href="visualizar_atividades.php?id_turma=<?= $id_turma ?>" class="voltar">Voltar</a>
    </div>
</body>
</html>