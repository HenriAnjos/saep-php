<?php
session_start();
include 'config.php';

// Verifica se o professor está logado
if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtém os dados do formulário
    $nome_turma = $_POST['nome_turma'] ?? null;
    $ano_turma = $_POST['ano_turma'] ?? null;
    $id_professor = $_SESSION['id_professor']; // ID do professor logado

    if (!empty($nome_turma) && !empty($ano_turma)) {
        // Insere a turma com o ID do professor logado
        $stmt = $conexao->prepare("INSERT INTO Turma (nome, ano, id_professor) VALUES (?, ?, ?)");
        $stmt->bind_param("sii", $nome_turma, $ano_turma, $id_professor);

        if ($stmt->execute()) {
            $mensagem = "Turma cadastrada com sucesso!";
            $tipo_mensagem = "sucesso";
        } else {
            $mensagem = "Erro ao cadastrar a turma.";
            $tipo_mensagem = "erro";
        }
        $stmt->close();
    } else {
        $mensagem = "Por favor, preencha todos os campos.";
        $tipo_mensagem = "erro";
    }
}
$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Nova Turma</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 220px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #2196F3;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            color: #333;
        }
        input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            padding: 10px 15px;
            background-color: #2196F3;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #1976D2;
        }
        .voltar {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #2196F3;
            text-decoration: none;
        }
        .voltar:hover {
            text-decoration: underline;
        }
        .mensagem {
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        .sucesso {
            background-color: #d4edda;
            color: #155724;
        }
        .erro {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Cadastrar Nova Turma</h1>
        <?php
        if (isset($mensagem)) {
            echo "<div class='mensagem " . $tipo_mensagem . "'>" . $mensagem . "</div>";
        }
        ?>
        <form action="cadastrar_turma.php" method="post">
            <label for="nome_turma">Nome da Turma:</label>
            <input type="text" id="nome_turma" name="nome_turma" required>
            <label for="ano_turma">Ano:</label>
            <input type="number" id="ano_turma" name="ano_turma" required>
            <button type="submit">Cadastrar</button>
        </form>
        <a href="professor.php" class="voltar">Voltar para a Página do Professor</a>
    </div>
</body>
</html>