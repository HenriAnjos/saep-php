<?php
$host = 'localhost';
$username = 'root';    
$password = 'root';        
$dbname = 'saep_db';    

$conexao = new mysqli($host, $username, $password, $dbname);

// if ($conexao->connect_errno) {
//     echo "Erro na conexão: " . $conexao->connect_error;
// } else {
//     echo "Conexão efetuada com sucesso";
// }
?>
