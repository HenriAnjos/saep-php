<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];
$id_turma = $_GET['id_turma'] ?? null;

if (!$id_turma) {
    echo "Turma não especificada.";
    exit;
}

$stmt_turma = $conexao->prepare("SELECT id_turma FROM Turma WHERE id_turma = ? AND id_professor = ?");
$stmt_turma->bind_param("ii", $id_turma, $id_professor);
$stmt_turma->execute();
$result_turma = $stmt_turma->get_result();

if ($result_turma->num_rows === 0) {
    echo "Erro: A turma não pertence a você.";
    exit;
}

$stmt_atividades = $conexao->prepare("DELETE FROM Atividade WHERE id_turma = ?");
$stmt_atividades->bind_param("i", $id_turma);
$stmt_atividades->execute();

$stmt_deletar_turma = $conexao->prepare("DELETE FROM Turma WHERE id_turma = ?");
$stmt_deletar_turma->bind_param("i", $id_turma);
$stmt_deletar_turma->execute();

if ($stmt_deletar_turma->affected_rows > 0) {
    header("Location: professor.php");
    exit;
} else {
    echo "Erro ao excluir a turma.";
}
?>
