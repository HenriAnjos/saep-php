<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    echo "Erro: Você precisa estar logado.";
    exit;
}

$id_professor = $_SESSION['id_professor'];
$id_atividade = $_GET['id_atividade'] ?? null;

if (!$id_atividade) {
    echo "Atividade não especificada.";
    exit;
}
$stmt = $conexao->prepare("
    SELECT A.id_atividade
    FROM Atividade A
    INNER JOIN Turma T ON A.id_turma = T.id_turma
    WHERE A.id_atividade = ? AND T.id_professor = ?
");
$stmt->bind_param("ii", $id_atividade, $id_professor);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Erro: Atividade não encontrada ou você não tem permissão para excluí-la.";
    exit;
}

$stmt_excluir = $conexao->prepare("DELETE FROM Atividade WHERE id_atividade = ?");
$stmt_excluir->bind_param("i", $id_atividade);
if ($stmt_excluir->execute()) {
    echo "Atividade excluída com sucesso!";
} else {
    echo "Erro ao excluir a atividade.";
}
?>
