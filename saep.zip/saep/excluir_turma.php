<?php
require_once 'auth.php';
require_once 'config.php';

$id_turma = $_GET['id_turma'] ?? 0;

$stmt = $conexao->prepare("SELECT COUNT(*) AS total FROM Atividade WHERE id_turma = ?");
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$stmt->bind_result($total);
$stmt->fetch();
$stmt->close();

if ($total > 0) {
    echo "<p>Não é possível excluir esta turma porque há atividades vinculadas.</p>";
    echo "<a href='professor.php'>Voltar</a>";
    exit;
}

$stmt = $conexao->prepare("DELETE FROM Turma WHERE id_turma = ?");
$stmt->bind_param('i', $id_turma);
if ($stmt->execute()) {
    header('Location: professor.php');
} else {
    echo "<p>Erro ao excluir a turma.</p>";
    echo "<a href='professor.php'>Voltar</a>";
}
$stmt->close();
?>
