<?php
require_once 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    // Busca no banco o professor pelo email e senha
    $stmt = $conexao->prepare("SELECT id_professor, nome FROM Professor WHERE email = ? AND senha = ?");
    $stmt->bind_param('ss', $email, $senha);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id_professor, $nome_professor);
        $stmt->fetch();

        // Define as variáveis de sessão
        $_SESSION['id_professor'] = $id_professor;
        $_SESSION['nome_professor'] = $nome_professor;

        header('Location: professor.php');
    } else {
        $erro = 'Email ou senha incorretos.';
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #2196F3;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #1976D2;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h1>Bem Vindo</h1>
        <input type="email" name="email" placeholder="E-Mail" required>
        <input type="password" name="senha" placeholder="Senha" required>
        <button type="submit">ENTRAR</button>
        <?php if (isset($erro)) echo "<p style='color:red; text-align:center;'>$erro</p>"; ?>
    </form>
</body>
</html>