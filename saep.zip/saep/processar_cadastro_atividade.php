<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];
$titulo = $_POST['titulo'] ?? null;
$descricao = $_POST['descricao'] ?? null;
$id_turma = $_POST['id_turma'] ?? null;

if (!empty($titulo) && !empty($id_turma)) {
    $stmt = $conexao->prepare("INSERT INTO Atividade (titulo, descricao, id_professor, id_turma) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $titulo, $descricao, $id_professor, $id_turma);

    if ($stmt->execute()) {
        header("Location: visualizar_atividades.php?id_turma=$id_turma");
        exit;
    } else {
        echo "Erro ao cadastrar a atividade.";
    }
    $stmt->close();
} else {
    echo "Por favor, preencha todos os campos obrigatórios.";
}
?>
