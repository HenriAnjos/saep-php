<?php
session_start();
include 'config.php';

// Verifica se o professor está logado
if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];

// Obtém as turmas do professor logado
$stmt = $conexao->prepare("SELECT id_turma, nome, ano FROM Turma WHERE id_professor = ?");
$stmt->bind_param("i", $id_professor);
$stmt->execute();
$result = $stmt->get_result();

$turmas = [];

while ($row = $result->fetch_assoc()) {
    $turmas[] = $row;
}

$stmt->close();
$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Professor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        .top-bar {
            background-color: #2196F3;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar a {
            color: white;
            text-decoration: none;
        }

        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 0 20px;
        }

        .header-actions {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background-color: #2196F3;
            color: white;
        }

        .btn-danger {
            background-color: #ff4444;
            color: white;
            padding: 4px 8px;
            font-size: 12px;
            margin-right: 5px;
        }

        .btn-success {
            background-color: #00C851;
            color: white;
            padding: 4px 8px;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            font-weight: 500;
            color: #333;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
        }

        .action-buttons a {
            text-decoration: none;
        }
        .container2 {
            padding: 120px;
        }
    </style>
</head>
<body>
    <div class="top-bar">
        <div>Bem-vindo, <?php echo $_SESSION['nome_professor']; ?></div>
        <a href="logout.php">Sair</a>
    </div>

    <div class="container2">
    <div class="container">
        <div class="header-actions">
            <a href="cadastrar_turma.php" class="btn btn-primary">Cadastrar turma</a>
        </div>

        <h2>Turmas</h2>
        <table>
            <thead>
                <tr>
                    <th>Número</th>
                    <th>Nome</th>
                    <th>Ano</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($turmas)): ?>
                    <tr>
                        <td colspan="4">Nenhuma turma cadastrada.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($turmas as $turma): ?>
                        <tr>
                            <td><?php echo $turma['id_turma']; ?></td>
                            <td><?php echo $turma['nome']; ?></td>
                            <td><?php echo $turma['ano']; ?></td>
                            <td class="action-buttons">
                                <a href="visualizar_atividades.php?id_turma=<?= $turma['id_turma'] ?>" class="btn btn-success">Ver Atividades</a>
                                <a href="excluir.php?id_turma=<?= $turma['id_turma'] ?>" class="btn btn-danger">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    </div>
</body>
</html>
