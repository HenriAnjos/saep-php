<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];
$id_turma = $_GET['id_turma'] ?? null;

if (!$id_turma) {
    echo "Turma não especificada.";
    exit;
}

$stmt_turma = $conexao->prepare("SELECT nome, ano FROM Turma WHERE id_turma = ? AND id_professor = ?");
$stmt_turma->bind_param("ii", $id_turma, $id_professor);
$stmt_turma->execute();
$result_turma = $stmt_turma->get_result();

if ($result_turma->num_rows === 0) {
    echo "Turma não encontrada ou não pertence a você.";
    exit;
}

$turma = $result_turma->fetch_assoc();

$stmt_atividades = $conexao->prepare("SELECT id_atividade, titulo, descricao FROM Atividade WHERE id_turma = ?");
$stmt_atividades->bind_param("i", $id_turma);
$stmt_atividades->execute();
$result_atividades = $stmt_atividades->get_result();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividades da Turma</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 100px;
            background-color: #f5f5f5;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h1, h2 {
            color: #2196F3;
            text-align: center;
        }
        ul {
            list-style-type: none;
            padding: 0;
            width: 100%;
        }
        li {
            background-color: #fff;
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .activity-content {
            flex-grow: 1;
        }
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #2196F3;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #1976D2;
        }
        .btn-danger {
            background-color: #f44336;
        }
        .btn-danger:hover {
            background-color: #d32f2f;
        }
        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
            width: 100%;
        }
        .btn-red {
            background-color: #f44336;
        }
        .btn-red:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
<h1>Atividades da Turma: <?= htmlspecialchars($turma['nome'] ?? 'Turma não encontrada') ?> (<?= $turma['ano'] ?>)</h1>

    <h2>Lista de Atividades</h2>
    <?php if ($result_atividades->num_rows > 0): ?>
        <ul>
            <?php while ($atividade = $result_atividades->fetch_assoc()): ?>
                <li>
                    <div class="activity-content">
                        <strong><?= htmlspecialchars($atividade['titulo']) ?>:</strong> 
                        <?= htmlspecialchars($atividade['descricao']) ?>
                    </div>
                    <a href="excluir_atividade.php?id_atividade=<?= $atividade['id_atividade'] ?>" class="btn btn-danger">Excluir</a>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>Não há atividades cadastradas para esta turma.</p>
    <?php endif; ?>

    <div class="actions">
        <a href="cadastrar_atividade.php?id_turma=<?= $id_turma ?>" class="btn">Cadastrar Nova Atividade</a>
        <a href="professor.php" class="btn btn-red">Voltar para Minhas Turmas</a>
    </div>
</body>
</html>
