<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_professor'])) {
    header("Location: login.php");
    exit;
}

$id_professor = $_SESSION['id_professor'];
$id_turma = $_GET['id_turma'] ?? null;

if (!$id_turma) {
    echo "Turma não especificada.";
    exit;
}

$stmt_turma = $conexao->prepare("SELECT nome, ano FROM Turma WHERE id_turma = ? AND id_professor = ?");
$stmt_turma->bind_param("ii", $id_turma, $id_professor);
$stmt_turma->execute();
$result_turma = $stmt_turma->get_result();

if ($result_turma->num_rows === 0) {
    echo "Turma não encontrada ou não pertence a você.";
    exit;
}

$turma = $result_turma->fetch_assoc();

$stmt_atividades = $conexao->prepare("SELECT id_atividade, titulo, descricao FROM Atividade WHERE id_turma = ?");
$stmt_atividades->bind_param("i", $id_turma);
$stmt_atividades->execute();
$result_atividades = $stmt_atividades->get_result();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Turma</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        h1, h2 {
            color: #2196F3;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background-color: #fff;
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #2196F3;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #1976D2;
        }
        a {
            color: #2196F3;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .excluir {
            color: #ff4444;
            margin-left: 10px;
        }
        .voltar {
            display: inline-block;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Turma: <?= htmlspecialchars($turma['nome']) ?> (<?= $turma['ano'] ?>)</h1>

    <h2>Atividades Cadastradas</h2>
    <?php if ($result_atividades->num_rows > 0): ?>
        <ul>
            <?php while ($atividade = $result_atividades->fetch_assoc()): ?>
                <li>
                    <strong><?= htmlspecialchars($atividade['titulo']) ?>:</strong> 
                    <?= htmlspecialchars($atividade['descricao']) ?>
                    <a href="excluir.php?id_atividade=<?= $atividade['id_atividade'] ?>" class="excluir">Excluir</a>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p>Não há atividades cadastradas para esta turma.</p>
    <?php endif; ?>

    <h2>Cadastrar Nova Atividade</h2>
    <form action="cadastrar_atividade.php" method="post">
        <input type="hidden" name="id_turma" value="<?= $id_turma ?>">
        <label for="titulo">Título da Atividade:</label>
        <input type="text" id="titulo" name="titulo" required>

        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao" rows="4"></textarea>

        <button type="submit">Cadastrar</button>
    </form>

    <a href="professor.php" class="voltar">Voltar para Minhas Turmas</a>
</body>
</html>